// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.11/esri/copyright.txt for details.
//>>built
define({"esri/widgets/Attribution/nls/Attribution":{widgetLabel:"\u5c5e\u6027",_localized:{}},"esri/widgets/Compass/nls/Compass":{widgetLabel:"\u7f57\u76d8\u4eea",reset:"\u91cd\u7f6e\u7f57\u76d8\u4eea\u65b9\u5411",_localized:{}},"esri/widgets/NavigationToggle/nls/NavigationToggle":{widgetLabel:"\u5bfc\u822a\u5207\u6362",toggle:"\u5207\u6362\u4ee5\u8fdb\u884c 3D \u5e73\u79fb\u6216\u65cb\u8f6c",_localized:{}},"esri/widgets/Zoom/nls/Zoom":{widgetLabel:"\u7f29\u653e",zoomIn:"\u653e\u5927",zoomOut:"\u7f29\u5c0f",
_localized:{}}});
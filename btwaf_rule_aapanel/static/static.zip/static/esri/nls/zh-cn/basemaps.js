// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.11/esri/copyright.txt for details.
//>>built
define({streets:"\u8857\u9053\u56fe",satellite:"\u5f71\u50cf\u56fe",hybrid:"\u5e26\u6807\u6ce8\u7684\u5f71\u50cf",terrain:"\u5e26\u6807\u6ce8\u7684 Terrain",topo:"\u5730\u5f62\u56fe",gray:"\u6d45\u7070\u8272\u753b\u5e03\u56fe","dark-gray":"\u6df1\u7070\u8272\u753b\u5e03\u56fe",oceans:"\u6d77\u6d0b\u56fe","national-geographic":"\u56fd\u5bb6\u5730\u7406",osm:"OpenStreetMap","streets-night-vector":"\u4e16\u754c\u8857\u9053\u56fe(\u591c\u95f4)","streets-relief-vector":"\u4e16\u754c\u8857\u9053\u56fe(\u542b\u5730\u8c8c)",
"streets-navigation-vector":"\u4e16\u754c\u5bfc\u822a\u56fe"});